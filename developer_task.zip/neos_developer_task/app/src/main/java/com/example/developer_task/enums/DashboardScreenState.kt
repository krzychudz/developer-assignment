package com.example.developer_task.enums

enum class DashboardScreenState {
    COMICS_FETCH_SUCCESS_STATE,
    COMICS_FETCH_FAILED_STATE,
    COMICS_FETCHING_STATE
}