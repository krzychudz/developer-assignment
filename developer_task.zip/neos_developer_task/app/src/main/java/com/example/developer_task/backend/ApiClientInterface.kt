package com.example.developer_task.backend

interface ApiClientInterface: ApiService