package com.example.developer_task.models

data class ComicsModel (
    val title: String?,
    val description: String?,
    val thumbnail: ThumbnailModel
)