package com.example.developer_task.models

data class ComicsResponse (
    val data: ComicsData
)