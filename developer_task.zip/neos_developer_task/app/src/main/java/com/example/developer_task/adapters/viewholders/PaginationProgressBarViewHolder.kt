package com.example.developer_task.adapters.viewholders

import android.view.View

class PaginationProgressBarViewHolder(view : View) : BaseViewHolder(view) {
}