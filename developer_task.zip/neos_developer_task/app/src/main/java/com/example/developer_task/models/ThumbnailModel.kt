package com.example.developer_task.models

data class ThumbnailModel (
    val path: String,
    val extension: String
)